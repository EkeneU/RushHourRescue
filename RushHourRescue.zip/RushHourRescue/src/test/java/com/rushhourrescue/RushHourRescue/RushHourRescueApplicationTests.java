package com.rushhourrescue.RushHourRescue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RushHourRescueApplicationTests {

	@Test
	void contextLoads() {
	}

}
